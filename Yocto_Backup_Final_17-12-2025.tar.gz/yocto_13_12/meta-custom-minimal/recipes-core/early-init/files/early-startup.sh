#!/bin/sh
# This script runs early during system startup (before inittab services)

# 1. FIX: D-Bus socket directory creation (must exist in tmpfs /run)
mkdir -p /run/dbus

# 2. FIX: Mount Cgroup V2 for containerd/runc/modern services
mount -t cgroup2 none /sys/fs/cgroup
