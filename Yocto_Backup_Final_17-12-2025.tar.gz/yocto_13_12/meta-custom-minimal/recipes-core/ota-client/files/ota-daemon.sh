#!/bin/sh

SERVER_URL="http://10.0.2.2:8000"
LOCAL_VER_FILE="/etc/image_version"
REMOTE_VER_FILE="/tmp/remote_version"
BUNDLE_URL="${SERVER_URL}/update-bundle-qemuarm.raucb"
LOCAL_BUNDLE="/data/update.raucb"

echo "OTA Daemon started. Monitoring ${SERVER_URL}..."

while true; do
    # 1. Clean up previous checks
    rm -f ${REMOTE_VER_FILE}

    # 2. Check current version
    if [ -f "${LOCAL_VER_FILE}" ]; then
        CURRENT_VER=$(cat ${LOCAL_VER_FILE})
    else
        CURRENT_VER="0"
    fi

    # 3. Fetch remote version
    wget -q -O ${REMOTE_VER_FILE} "${SERVER_URL}/version.txt"

    if [ $? -eq 0 ]; then
        NEW_VER=$(cat ${REMOTE_VER_FILE})

        # 4. Compare Versions
        if [ "$NEW_VER" -gt "$CURRENT_VER" ]; then
            echo "Update found! Current: ${CURRENT_VER}, New: ${NEW_VER}"

            # --- FIX: DOWNLOAD FIRST (Avoids Streaming Errors) ---
            echo "Downloading bundle to ${LOCAL_BUNDLE}..."
            wget -O ${LOCAL_BUNDLE} "${BUNDLE_URL}"

            if [ $? -eq 0 ]; then
                echo "Download complete. Starting local installation..."
                rauc install ${LOCAL_BUNDLE}

                if [ $? -eq 0 ]; then
                    echo "Installation successful. Rebooting in 5 seconds..."
                    rm -f ${LOCAL_BUNDLE}
                    sleep 5
                    reboot
                else
                    echo "Installation failed. Will retry later."
                fi
            else
                echo "Download failed."
            fi
        else
            echo "System is up to date (Ver: ${CURRENT_VER})."
        fi
    else
        echo "Could not reach update server."
    fi

    # Wait 60 seconds before next check
    sleep 60
done
