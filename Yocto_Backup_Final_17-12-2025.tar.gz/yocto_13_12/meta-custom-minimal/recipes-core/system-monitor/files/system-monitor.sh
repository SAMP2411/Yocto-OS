#!/bin/sh

# Wait for network
sleep 5

while true; do
    # --- 1. EXISTING METRICS ---
    # Clean up uptime to show just the load average part
    # output example: " 13:23:05 up 1 min,  load average: 0.08, 0.01, 0.00"
    LOAD_AVG=$(uptime | awk -F'load average:' '{ print $2 }')

    # RAM
    MEM_FREE=$(free | grep Mem | awk '{print $4}')

    # Container Count
    CONTAINER_COUNT=$(ctr tasks list 2>/dev/null | grep -c "RUNNING")

    # --- 2. NEW METRICS ---

    # Disk Usage of /data partition (Percentage used)
    # df output example: "/dev/vda4      495.8M      2.3M    456.2M   1% /data"
    DISK_USAGE=$(df /data | awk 'NR==2 {print $5}')

    # IP Address (Get the IP of eth0)
    IP_ADDR=$(ip -4 addr show eth0 | awk '/inet / {print $2}' | cut -d/ -f1)

    # CPU Temp (Works on RPi, returns "N/A" on QEMU)
    if [ -f /sys/class/thermal/thermal_zone0/temp ]; then
        # Convert millidegrees to degrees
        TEMP_RAW=$(cat /sys/class/thermal/thermal_zone0/temp)
        CPU_TEMP="$((TEMP_RAW / 1000))C"
    else
        CPU_TEMP="N/A (QEMU)"
    fi

    # --- 3. SEND LOG ---
    # We organize it with clear tags |
    LOG_MSG="IP: $IP_ADDR | Load: $LOAD_AVG | MemFree: ${MEM_FREE}K | Disk(/data): $DISK_USAGE | Temp: $CPU_TEMP | Containers: $CONTAINER_COUNT"

    logger -t STATUS "$LOG_MSG"

    sleep 10
done
